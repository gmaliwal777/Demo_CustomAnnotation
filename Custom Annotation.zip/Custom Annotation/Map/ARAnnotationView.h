//
//  ARAnnotationView.h
//  eCitzens
//
//  Created by Ghanshyam on 4/15/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>


@class ARPlace;
@class ARGeoCoordinate;

@interface ARAnnotationView : UIView<UITableViewDelegate,UITableViewDataSource>{
    UILabel         *lblAnnotatinDesc;
    NSString        *selection;
    NSString        *movedToDetail;
}

@property (nonatomic,strong)    UIImageView             *customImageView;
@property (nonatomic,assign)    BOOL                    refresh;
@property (nonatomic,strong)    ARGeoCoordinate         *coordinate;
@property (nonatomic,weak)      ARPlace                 *annotation;
@property (nonatomic,strong)    UIButton                *btnTap;
@property (nonatomic,assign)    UIDeviceOrientation     deviceOrientation;
@property (nonatomic,weak)      UITableView             *tableView;


-(id)initWithCoordinate:(ARGeoCoordinate *)coordinate Annotation:(ARPlace *)annote;


@end
