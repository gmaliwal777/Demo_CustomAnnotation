//
//  ARPlace.m
//  eCitzens
//
//  Created by Ghanshyam on 4/15/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "ARPlace.h"
#import "ISSUE.h"

@implementation ARPlace
#pragma mark--
#pragma mark-- Annotation Lifecycle
-(id)initWithLocation:(CLLocationCoordinate2D)coord WithIssue:(ISSUE *)issue{
    self = [super init];
    if (self) {
        _coordinate = coord;
        if (_arrIssues==nil) {
            _arrIssues = [[NSMutableArray alloc] init];
        }
        [_arrIssues addObject:issue];
    }
    return self;
}

-(void)dealloc{
    NSLog(@"ARPlace dealloc");
}

#pragma mark--
#pragma mark-- Custom Method
-(void)addMoreIssue:(ISSUE *)issue{
    //KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    [_arrIssues addObject:issue];
}

@end
