//
//  KIPLAnnotation.m
//  eCitzens
//
//  Created by Ghanshyam on 4/3/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "KIPLAnnotation.h"

@implementation KIPLAnnotation

#pragma mark--
#pragma mark-- Annotation Lifecycle
-(id)initWithLocation:(CLLocationCoordinate2D)coord WithIssue:(ISSUE *)issue{
    self = [super init];
    if (self) {
        _coordinate = coord;
        if (_arrIssues==nil) {
            _arrIssues = [[NSMutableArray alloc] init];
        }
        [_arrIssues addObject:issue];
        _title = @"Item";
        //_issueAnnote = issue;
    }
    return self;
}

-(void)dealloc{
    NSLog(@"KIPLAnnotation dealloc");
}

#pragma mark--
#pragma mark-- Custom Method
-(void)addMoreIssue:(ISSUE *)issue{
    //KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    [_arrIssues addObject:issue];
}

-(BOOL)alreadyAdded:(ISSUE *)issue{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.issue_id == %@",[issue issue_id]];
    NSArray *arrFilter = [_arrIssues filteredArrayUsingPredicate:predicate];
    if (arrFilter.count>0) {
        NSLog(@"already added on map");
        return YES;
    }
    return NO;
}

@end
