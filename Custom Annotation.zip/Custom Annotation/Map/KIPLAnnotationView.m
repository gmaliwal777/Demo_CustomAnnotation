//
//  KIPLAnnotationView.m
//  eCitzens
//
//  Created by Ghanshyam on 4/3/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "KIPLAnnotationView.h"
#import "KIPLAnnotation.h"
#import "ISSUE.h"
#import "CATEGORY.h"
#import "STATUS.h"
#import "CallOutView.h"
#import "IssueDetailVC.h"


@implementation KIPLAnnotationView

#define CALLOUTVIEW_TAG     420

#pragma mark--
#pragma mark-- MKAnnotationView LifeCycle

- (id) initWithAnnotation: (id <MKAnnotation>) annotation reuseIdentifier: (NSString *) reuseIdentifier
{
    self =[super initWithAnnotation: annotation reuseIdentifier: reuseIdentifier];
    if (self != nil)
    {
        [self setFrame:CGRectMake(0, 0, 30, 30)];
        [self setBackgroundColor:[UIColor clearColor]];
        
        //Custom Annotation Image View
        _customImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [_customImageView setBackgroundColor:[UIColor clearColor]];
        [self addSubview:_customImageView];
        
        
        //Custom Annotation Title View
        lblAnnotatinDesc = [[UILabel alloc] initWithFrame:CGRectZero];
        [lblAnnotatinDesc setFont:[UIFont fontWithName:@"Helvetica Neue" size:8]];
        [lblAnnotatinDesc setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [lblAnnotatinDesc setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:lblAnnotatinDesc];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [self addGestureRecognizer:tapGesture];
    }
    return self;
}

-(void)dealloc{
    NSLog(@"annotation view dealloc");
}


-(void)drawRect:(CGRect)rect{
    NSLog(@"drawing rect calling");
    //self.refresh = YES;
}

-(void)setSelected:(BOOL)selected{
    //NSLog(@"selected is %@",(selected?@"YES":@"NO"));
}

#pragma mark--
#pragma mark-- Setter & Getter

-(void)setRefresh:(BOOL)refresh{
    [self setUpView];
}

-(BOOL)getSelection{
    return [selection boolValue];
}

#pragma mark--
#pragma mark-- Gesture Recognizer
-(void)tapAction:(UITapGestureRecognizer *)tapGesture{
    KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    NSLog(@"tapped loc lat = %f , lng = %f",annotation.coordinate.latitude,annotation.coordinate.longitude);
    [self.superview bringSubviewToFront:self];
    for (ISSUE *issue in annotation.arrIssues) {
        NSLog(@"issue on location lat = %f ,lng = %f",[issue.latitude floatValue],[issue.longitude floatValue]);
    }
    if ([annotation.arrIssues count]>1) {
        CGPoint touchPoint = [tapGesture locationInView:self];
        UIView *callOut = (UIView *)[self viewWithTag:CALLOUTVIEW_TAG];
        
        if (CGRectContainsPoint(callOut.frame, touchPoint)) {
            //No Action
            
        }else if(CGRectContainsPoint(_customImageView.frame, touchPoint)){
            CGRect currentFrame = self.frame;
            if (![selection boolValue]) {
                [self setValue:@"YES" forKey:@"selection"];
                float callOutHeight = [self getListCount]*44;
                
                UIImage *calloutImage = [UIImage imageNamed:@"CallOutBackground"];
                UIImage *_customImage = [self getHighlightedAnnoteImage];
                _customImageView.image = _customImage;
                
                double width = calloutImage.size.width+_customImage.size.width;
                
                [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, width, (callOutHeight>250?250:callOutHeight))];
                [self setCenterOffset:CGPointMake((width-currentFrame.size.width)/2,((callOutHeight>250?250:callOutHeight)-currentFrame.size.height)/2)];
                
                CGRect callOutFrame = CGRectMake(50,0 , calloutImage.size.width, (callOutHeight>250?250:callOutHeight));
                CallOutView *callOut = [[CallOutView alloc] initWithFrame:callOutFrame];
                callOut.arrIssues = annotation.arrIssues;
                callOut.center = CGPointMake(callOut.center.x, self.frame.size.height/2);
                callOut.tag = CALLOUTVIEW_TAG;
                [self addSubview:callOut];
                [[NSNotificationCenter defaultCenter] postNotificationName:centerCallOutNotification object:self];
            }else{
                UIImage *_customImage = [self getAnnoteImage];
                _customImageView.image = _customImage;
                [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, _customImage.size.width,_customImage.size.height)];
                [self setCenterOffset:CGPointMake(0, 0)];
                [self setValue:@"NO" forKey:@"selection"];
                UIView *callOut = (UIView *)[self viewWithTag:CALLOUTVIEW_TAG];
                if (callOut) {
                    callOut.frame = CGRectZero;
                    [callOut removeFromSuperview];
                }
            }
        }
    }else{
        
        UIImage *_customImage = [self getHighlightedAnnoteImage];
        _customImageView.image = _customImage;
        //Moving directly to Detail Screen
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        IssueDetailVC *issueDetailVC = (IssueDetailVC *)[storyboard instantiateViewControllerWithIdentifier:ISSUE_DETAIL_STORYBOARD_ID];
        issueDetailVC.issue = (ISSUE *)[annotation.arrIssues objectAtIndex:0];
        issueDetailVC.modellyPresented = YES;
        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        [appdelegate.navigationController presentViewController:issueDetailVC animated:YES completion:^{
            UIImage *_customImage = [self getAnnoteImage];
            _customImageView.image = _customImage;
        }];
//        [appdelegate.navigationController pushViewController:issueDetailVC animated:YES];
    }
}

-(int)getListCount{
    KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    NSMutableDictionary  *dictIssues = [[NSMutableDictionary alloc] init];
    
    for (ISSUE *localIssue in annotation.arrIssues) {
        NSString *category = localIssue.category.code;
        if ([dictIssues objectForKey:category]) {
            NSMutableArray *arrMutableIssues = [dictIssues objectForKey:category];
            [arrMutableIssues addObject:localIssue];
        }else{
            NSMutableArray *arrMutalbeIssues = [[NSMutableArray alloc] init];
            [arrMutalbeIssues addObject:localIssue];
            [dictIssues setObject:arrMutalbeIssues forKey:category];
        }
    }
    
    NSArray *arrKeys = [dictIssues allKeys];
    NSMutableArray  *arrItems = [[NSMutableArray alloc] init];
    for (int counter = 0;counter<arrKeys.count;counter++) {
        NSArray *arrFormattedIssues = [dictIssues objectForKey:[arrKeys objectAtIndex:counter]];
        NSDictionary *dictItem = [[NSDictionary alloc] initWithObjectsAndKeys:[arrKeys objectAtIndex:counter],@"category", nil];
        [arrItems addObject:dictItem];
        for (int inner=0; inner<arrFormattedIssues.count; inner++) {
            ISSUE *issue = [arrFormattedIssues objectAtIndex:inner];
            [arrItems addObject:issue];
        }
    }
    return (int)[arrItems count];
}

#pragma mark--
#pragma mark-- Custom Methods

-(void)hideCallOutView{
    
    UIImage *_customImage = [self getAnnoteImage];
    _customImageView.image = _customImage;
    
    CallOutView *callOutView = (CallOutView *)[self viewWithTag:CALLOUTVIEW_TAG];
    CGRect currentFrame = self.frame;
    if (callOutView) {
        UIImage *_customImage = [self getAnnoteImage];
        [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, _customImage.size.width,_customImage.size.height)];
        [self setCenterOffset:CGPointMake(0, 0)];
        [callOutView removeFromSuperview];
        [self setValue:@"NO" forKey:@"selection"];
    }
}

-(void)bringCallOutInFront{
   // [self.superview bringSubviewToFront:self];
    dispatch_time_t dispatchAfter = dispatch_time(DISPATCH_TIME_NOW, 2);
    dispatch_after(dispatchAfter, dispatch_get_main_queue(), ^{
        [self tapAction:[[UITapGestureRecognizer alloc] init]];
    });
}

-(void)setUpView{
    NSLog(@"setup annotation view");
    [self hideCallOutView];
    KIPLAnnotation *annot = (KIPLAnnotation *)self.annotation;
     ISSUE *issue = [[annot arrIssues] objectAtIndex:0];
    UIImage *_customImage = self.isRecentlyAdded?[self getRecentlyAnnoteImage]:[self getAnnoteImage];
    
    self.frame = CGRectMake(0,0,_customImage.size.width,_customImage.size.height);
    //Custom Pin
    
    _customImageView.image = _customImage;
    [_customImageView sizeToFit];
    
    
    //Title Creation
//    if ([annot.arrIssues count]>1) {
//        lblAnnotatinDesc.text = @"More";
//    }else{
//        lblAnnotatinDesc.text = issue.category.code;
//    }
    [lblAnnotatinDesc sizeToFit];
    lblAnnotatinDesc.center = CGPointMake(self.frame.size.width/2, self.frame.size.height+5);
}

- (UIImage *)getAnnoteImage{
    KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    UIImage *_customImage ;
    if ([[annotation arrIssues] count]>1) {
        _customImage = [UIImage imageNamed:@"MoreIssueIcon"];
//        lblAnnotatinDesc.text = @"More";
        [lblAnnotatinDesc sizeToFit];
    }else{
        
        ISSUE *issue = [[annotation arrIssues] objectAtIndex:0];
        
        if ([[issue.category.code uppercaseString] isEqualToString:CLEANLINESS]
            && [[issue.status.status_code  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"ResolvedCleanlinessIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:CLEANLINESS]){
            //Un-Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"CleanlinessIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:DISASTER] && [[issue.status.status_code  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"ResolvedDisasterIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:DISASTER]){
            //Un-Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"DisasterIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:SAFETY] && [[issue.status.status_code  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Safety Image
            _customImage = [UIImage imageNamed:@"ResolvedSafetyIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:SAFETY]){
            //Un-Resolved Safety Image
            _customImage = [UIImage imageNamed:@"SafetyIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:RECYCLING] && [[issue.status.status_code  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"ResolvedRecycleIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:RECYCLING]){
            //Un-Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"RecycleIcon"];
        }
    }
    
    return _customImage;
}

- (UIImage *)getHighlightedAnnoteImage{
    KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    UIImage *_customImage ;
    if ([[annotation arrIssues] count]>1) {
        _customImage = [UIImage imageNamed:@"SelectedAllIcon"];
        //        lblAnnotatinDesc.text = @"More";
        [lblAnnotatinDesc sizeToFit];
    }else{
        
        ISSUE *issue = [[annotation arrIssues] objectAtIndex:0];
        
        if ([[issue.category.code uppercaseString] isEqualToString:CLEANLINESS]){
            //Un-Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"SelectedCleanlinessIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:DISASTER]){
            //Un-Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"SelectedDisasterIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:SAFETY]){
            //Un-Resolved Safety Image
            _customImage = [UIImage imageNamed:@"SelectedSafetyIcon"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:RECYCLING]){
            //Un-Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"SelectedRecycleIcon"];
        }
    }
    
    return _customImage;
}

- (UIImage *)getRecentlyAnnoteImage{
    KIPLAnnotation *annotation = (KIPLAnnotation *)self.annotation;
    UIImage *_customImage ;
    if ([[annotation arrIssues] count]>1) {
        _customImage = [UIImage imageNamed:@"recentlyAll"];
        //        lblAnnotatinDesc.text = @"More";
        [lblAnnotatinDesc sizeToFit];
    }else{
        
        ISSUE *issue = [[annotation arrIssues] objectAtIndex:0];
        
        if ([[issue.category.code uppercaseString] isEqualToString:CLEANLINESS]){
            //Un-Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"recentlyClean"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:DISASTER]){
            //Un-Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"recentlyDisaster"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:SAFETY]){
            //Un-Resolved Safety Image
            _customImage = [UIImage imageNamed:@"recentlySafety"];
        }else if ([[issue.category.code uppercaseString] isEqualToString:RECYCLING]){
            //Un-Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"recentlyRecyle"];
        }
    }
    
    return _customImage;
}

-(void)prepareForReuse{
    NSLog(@"prepareForReuse calling");
//    lblAnnotatinDesc.text = @"";
    [lblAnnotatinDesc sizeToFit];
    lblAnnotatinDesc.center = CGPointMake(self.frame.size.width/2, self.frame.size.height+5);
    
    _customImageView.image = nil;
}


@end
