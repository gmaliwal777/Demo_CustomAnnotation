//
//  ARAnnotationView.m
//  eCitzens
//
//  Created by Ghanshyam on 4/15/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "ARAnnotationView.h"
#import "ISSUE.h"
#import "CATEGORY.h"
#import "STATUS.h"
#import "CallOutView.h"
#import "IssueDetailVC.h"
#import "ARPlace.h"
#import "ARIssueDetailCell.h"

#define CALLOUTVIEW_TAG     420


@implementation ARAnnotationView

-(id)initWithCoordinate:(ARGeoCoordinate *)coordinate Annotation:(ARPlace *)annote{
    self = [super init];
    if (self != nil)
    {
        NSLog(@"arannotationview init");
        [self setFrame:CGRectMake(0, 0, 50, 50)];
        [self setBackgroundColor:[UIColor clearColor]];
        
        _coordinate = coordinate;
        _annotation = annote;
        
        
        //Custom Annotation Image View
        _customImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
        [_customImageView setBackgroundColor:[UIColor clearColor]];
        _customImageView.userInteractionEnabled = NO;
        [_customImageView sizeToFit];
        [self addSubview:_customImageView];
        
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [self addGestureRecognizer:tapGesture];
//        [_customImageView addGestureRecognizer:tapGesture];
    }
    return self;
}

-(void)dealloc{
    NSLog(@"ARAnnotationView dealloc");
    _annotation = nil;
    _coordinate = nil;
}


-(void)drawRect:(CGRect)rect{
    NSLog(@"arannotationview drawing rect calling");
    CGRect currentFrame = self.frame;
    NSLog(@"current frame is %@",NSStringFromCGRect(currentFrame));
    [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, 60, 60)];
    UIImage *image = [self getAnnoteImage];
    _customImageView.image = image;
    [_customImageView sizeToFit];
}


#pragma mark--
#pragma mark-- Setter & Getter
-(void)setUpView{
   
}

-(BOOL)getSelection{
    return [selection boolValue];
}


#pragma mark--
#pragma mark-- Gesture Recognizer
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touches began in arannotationview");
}
-(void)tapAction:(UITapGestureRecognizer *)tapGesture{
//    //Tap Me Set to YES
//    [self setValue:@"YES" forKey:@"tapMe"];
    
    
    ARPlace *annotation = (ARPlace *)self.annotation;
    NSLog(@"tapped loc lat = %f , lng = %f",annotation.coordinate.latitude,annotation.coordinate.longitude);
    [self.superview bringSubviewToFront:self];
    
    
    CGPoint touchPoint = [tapGesture locationInView:self];
    if(CGRectContainsPoint(_customImageView.frame, touchPoint)){
        if (![selection boolValue]) {
            [self setValue:@"YES" forKey:@"selection"];
        }else{
            [self setValue:@"NO" forKey:@"selection"];
        }
    }
    
    
//    if ([annotation.arrIssues count]>1) {
//        CGPoint touchPoint = [tapGesture locationInView:self];
//        UIView *callOut = (UIView *)[self viewWithTag:CALLOUTVIEW_TAG];
//        NSLog(@"touch point is %@",NSStringFromCGPoint(touchPoint));
//        NSLog(@"custom image view is %@",_customImageView);
//        NSLog(@"image view frame is %@",NSStringFromCGRect(_customImageView.frame));
//        if (CGRectContainsPoint(callOut.frame, touchPoint)) {
//            //No Action
//            
//        }else if(CGRectContainsPoint(_customImageView.frame, touchPoint)){
//            CGRect currentFrame = self.frame;
//            if (![selection boolValue]) {
//                [self setValue:@"YES" forKey:@"selection"];
//                float callOutHeight = [self getListCount]*44;
//                [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, 220, (callOutHeight>250?250:callOutHeight))];
//                
//                //[self setCenterOffset:CGPointMake((220-currentFrame.size.width)/2,((callOutHeight>250?250:callOutHeight)-currentFrame.size.height)/2)];
//                
//                CGRect callOutFrame = CGRectMake(50,0 , 220, (callOutHeight>250?250:callOutHeight));
//                CallOutView *callOut = [[CallOutView alloc] initWithFrame:callOutFrame];
//                callOut.arrIssues = annotation.arrIssues;
//                callOut.center = CGPointMake(callOut.center.x, self.frame.size.height/2);
//                callOut.tag = CALLOUTVIEW_TAG;
//                [self addSubview:callOut];
//                [[NSNotificationCenter defaultCenter] postNotificationName:centerCallOutNotification object:self];
//            }else{
//                UIImage *_customImage = [self getAnnoteImage];
//                [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, _customImage.size.width,_customImage.size.height)];
//                //[self setCenterOffset:CGPointMake(0, 0)];
//                [self setValue:@"NO" forKey:@"selection"];
//                UIView *callOut = (UIView *)[self viewWithTag:CALLOUTVIEW_TAG];
//                if (callOut) {
//                    callOut.frame = CGRectZero;
//                    [callOut removeFromSuperview];
//                }
//            }
//        }
//    }else{
//        [self setValue:@"YES" forKey:@"selection"];
//        
//        //Moving directly to Detail Screen
//        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        
//        IssueDetailVC *issueDetailVC = (IssueDetailVC *)[storyboard instantiateViewControllerWithIdentifier:ISSUE_DETAIL_STORYBOARD_ID];
//        issueDetailVC.issue = (ISSUE *)[annotation.arrIssues objectAtIndex:0];
//        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//        [appdelegate.navigationController pushViewController:issueDetailVC animated:YES];
//    }
}


#pragma mark--
#pragma mark-- Custom Methods

-(void)hideCallOutView{
    CallOutView *callOutView = (CallOutView *)[self viewWithTag:CALLOUTVIEW_TAG];
    CGRect currentFrame = self.frame;
    if (callOutView) {
        UIImage *_customImage = [self getAnnoteImage];
        [self setFrame:CGRectMake(currentFrame.origin.x, currentFrame.origin.y, _customImage.size.width,_customImage.size.height)];
        //[self setCenterOffset:CGPointMake(0, 0)];
        [callOutView removeFromSuperview];
        [self setValue:@"NO" forKey:@"selection"];
    }
}


-(int)getListCount{
    ARPlace *annotation = (ARPlace *)self.annotation;
    NSMutableDictionary  *dictIssues = [[NSMutableDictionary alloc] init];
    
    for (ISSUE *localIssue in annotation.arrIssues) {
        NSString *category = localIssue.category.code;
        if ([dictIssues objectForKey:category]) {
            NSMutableArray *arrMutableIssues = [dictIssues objectForKey:category];
            [arrMutableIssues addObject:localIssue];
        }else{
            NSMutableArray *arrMutalbeIssues = [[NSMutableArray alloc] init];
            [arrMutalbeIssues addObject:localIssue];
            [dictIssues setObject:arrMutalbeIssues forKey:category];
        }
    }
    
    NSArray *arrKeys = [dictIssues allKeys];
    NSMutableArray  *arrItems = [[NSMutableArray alloc] init];
    for (int counter = 0;counter<arrKeys.count;counter++) {
        NSArray *arrFormattedIssues = [dictIssues objectForKey:[arrKeys objectAtIndex:counter]];
        NSDictionary *dictItem = [[NSDictionary alloc] initWithObjectsAndKeys:[arrKeys objectAtIndex:counter],@"category", nil];
        [arrItems addObject:dictItem];
        for (int inner=0; inner<arrFormattedIssues.count; inner++) {
            ISSUE *issue = [arrFormattedIssues objectAtIndex:inner];
            [arrItems addObject:issue];
        }
    }
    return (int)[arrItems count];
//    return 1;
}


-(UIImage *)getAnnoteImage{
    UIImage *_customImage ;
    if ([[_annotation arrIssues] count]>1) {
        _customImage = [UIImage imageNamed:@"MoreIssueIcon"];
//        lblAnnotatinDesc.text = @"More";
        [lblAnnotatinDesc sizeToFit];
    }else{
        //ARPlace *annote = (ARPlace *)_annotation;
        NSString *annoteCategory = _annotation.annoteCategory;
        NSString *annoteStatus = _annotation.annoteStatus;
        if ([[annoteCategory uppercaseString] isEqualToString:CLEANLINESS]
            && [[annoteStatus  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"ResolvedCleanlinessIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:CLEANLINESS]){
            //Un-Resolved Cleanliness Image
            _customImage = [UIImage imageNamed:@"CleanlinessIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:DISASTER] && [[annoteStatus  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"ResolvedDisasterIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:DISASTER]){
            //Un-Resolved Disaster Image
            _customImage = [UIImage imageNamed:@"DisasterIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:SAFETY] && [[annoteStatus  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Safety Image
            _customImage = [UIImage imageNamed:@"ResolvedSafetyIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:SAFETY]){
            //Un-Resolved Safety Image
            _customImage = [UIImage imageNamed:@"SafetyIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:RECYCLING] && [[annoteStatus  uppercaseString] isEqualToString:RESOLVED]) {
            //Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"ResolvedRecycleIcon"];
        }else if ([[annoteCategory uppercaseString] isEqualToString:RECYCLING]){
            //Un-Resolved Recycling Image
            _customImage = [UIImage imageNamed:@"RecycleIcon"];
        }
    }
    return _customImage;
}


#pragma mark--
#pragma mark-- UITableViewDelegate & DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    ARPlace *annotation = (ARPlace *)self.annotation;
    return annotation.arrIssues.count;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ARIssueDetailCell *issueCell = [tableView dequeueReusableCellWithIdentifier:AR_DEFAULT_CELL_IDENTIFIER];
    if (issueCell == nil) {
        issueCell = [[ARIssueDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AR_DEFAULT_CELL_IDENTIFIER];
    }
    if (_deviceOrientation == UIDeviceOrientationPortrait) {
        issueCell.cnstReadMoreWidth.constant = 40;
        issueCell.lblReadMore.text = @"   >>";
    }else{
        issueCell.cnstReadMoreWidth.constant =115;
        issueCell.lblReadMore.text = @"Read More >>";
    }
    
    //Assigning ItemDidSelect Operation
    issueCell.weakSuper = self;
    [issueCell.btnTap addTarget:self action:@selector(itemDidSelect:) forControlEvents:UIControlEventTouchUpInside];
    
    ARPlace *annotation = (ARPlace *)self.annotation;
    ISSUE *issue = [annotation.arrIssues objectAtIndex:indexPath.row];
    
    issueCell.lblIssueTitle.text = issue.title;
    issueCell.lblIssueDesc.text = issue.desc;
    if ([[issue.category.code uppercaseString] isEqualToString:CLEANLINESS]) {
        issueCell.imgIssueCategory.image = [UIImage imageNamed:@"ARCleanlinessIcon"];
    }else if ([[issue.category.code uppercaseString] isEqualToString:RECYCLING]){
        issueCell.imgIssueCategory.image = [UIImage imageNamed:@"ARRecyclingIcon"];
    }else if ([[issue.category.code uppercaseString] isEqualToString:SAFETY]){
        issueCell.imgIssueCategory.image = [UIImage imageNamed:@"ARSafetyicon"];
    }else if ([[issue.category.code uppercaseString] isEqualToString:DISASTER]){
        issueCell.imgIssueCategory.image = [UIImage imageNamed:@"ARDisasterIcon"];
    }
    
    
    CLLocation *toLocation = [[CLLocation alloc] initWithLatitude:[issue.latitude floatValue] longitude:[issue.longitude floatValue]];
    issueCell.lblDistance.text = [NSString stringWithFormat:@"%d m",[self getDitanceToLocation:toLocation]];
    return issueCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

-(int)getDitanceToLocation:(CLLocation *)toLocation{
    float currentLat = [[AppUtility getUserDefaultValue:LOCATION_LAT] floatValue];
    float currentLng = [[AppUtility getUserDefaultValue:LOCATION_LNG] floatValue];
    CLLocation *currentLoc = [[CLLocation alloc] initWithLatitude:currentLat longitude:currentLng];
    return [currentLoc distanceFromLocation:toLocation];
}


#pragma mark--
#pragma mark-- IBAction Methods
-(void)itemDidSelect:(UIButton *)btnSender{
    CGPoint buttonPosition = [btnSender convertPoint:CGPointZero toView:_tableView];
    NSIndexPath *indexPath = [_tableView indexPathForRowAtPoint:buttonPosition];
    if (indexPath) {
        //Notifiying That User Moved to Detail Screen
        [self setValue:@"YES" forKey:@"movedToDetail"];
        
        
        ARPlace *annotation = (ARPlace *)self.annotation;
        ISSUE *issue = (ISSUE *)[annotation.arrIssues objectAtIndex:indexPath.row];
        
        //Moving directly to Detail Screen
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        IssueDetailVC *issueDetailVC = (IssueDetailVC *)[storyboard instantiateViewControllerWithIdentifier:ISSUE_DETAIL_STORYBOARD_ID];
        issueDetailVC.issue = issue;
        issueDetailVC.modellyPresented = YES;
        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        [appdelegate.navigationController presentViewController:issueDetailVC animated:YES completion:NULL];
    }
}


@end
