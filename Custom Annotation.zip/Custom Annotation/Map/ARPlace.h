//
//  ARPlace.h
//  eCitzens
//
//  Created by Ghanshyam on 4/15/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ISSUE;

@interface ARPlace : NSObject

@property (nonatomic, assign)   CLLocationCoordinate2D coordinate;
@property (nonatomic, strong)   NSString               *annoteTitle;
@property (nonatomic, strong)   NSString               *annoteCategory;
@property (nonatomic, strong)   NSString               *annoteStatus;
@property (nonatomic, strong)   NSMutableArray         *arrIssues;
@property (nonatomic,strong)    NSString               *strLat;
@property (nonatomic,strong)    NSString               *strLng;


-(id)initWithLocation:(CLLocationCoordinate2D)coord WithIssue:(ISSUE *)issue;
-(void)addMoreIssue:(ISSUE *)issue;

@end
