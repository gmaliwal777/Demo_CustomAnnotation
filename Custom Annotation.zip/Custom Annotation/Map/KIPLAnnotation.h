//
//  KIPLAnnotation.h
//  eCitzens
//
//  Created by Ghanshyam on 4/3/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "ISSUE.h"

/**
 *  KIPLAnnotation adopt MKAnnotation protocol
 */
@interface KIPLAnnotation : NSObject<MKAnnotation>
{
    
}


@property (nonatomic,readonly)  CLLocationCoordinate2D  coordinate;
@property (nonatomic,strong)    NSMutableArray          *arrIssues;
@property (nonatomic,copy)      NSString                *title;
@property (nonatomic,strong)    NSString                *strLat;
@property (nonatomic,strong)    NSString                *strLng;

-(id)initWithLocation:(CLLocationCoordinate2D)coord WithIssue:(ISSUE *)issue;
-(void)addMoreIssue:(ISSUE *)issue;
-(BOOL)alreadyAdded:(ISSUE *)issue;

@end
