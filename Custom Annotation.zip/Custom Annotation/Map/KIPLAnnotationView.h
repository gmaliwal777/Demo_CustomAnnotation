//
//  KIPLAnnotationView.h
//  eCitzens
//
//  Created by Ghanshyam on 4/3/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface KIPLAnnotationView : MKAnnotationView{
    UILabel         *lblAnnotatinDesc;
    NSString        *selection;
}

@property (nonatomic,strong)    UIImageView     *customImageView;
@property (nonatomic,assign)    BOOL            refresh;
@property (nonatomic,assign)    BOOL            isRecentlyAdded;

-(void)hideCallOutView;
-(BOOL)getSelection;
-(void)bringCallOutInFront;
-(void)reShowCallOutView;

@end
