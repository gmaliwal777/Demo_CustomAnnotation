//
//  MapVC.h
//  eCitizens
//
//  Created by Ghanshyam on 3/10/15.
//  Copyright (c) 2015 Suchita. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "FancyTabBar.h"
#import "YCameraViewController.h"
#import "KIPLAnnotationView.h"
#import "Loader.h"

@interface MapVC : UIViewController<FancyTabBarDelegate,YCameraViewControllerDelegate,MKMapViewDelegate,IssueListWSDelegate>{
    dispatch_once_t                 dispatchMapInitialization;
    
    Loader                          *loader;
    AlertView                       *alert;
    CLLocationCoordinate2D          defaultCenterCordinate;
    CategoryType                    category;
    NSMutableArray                  *arrPINS;
    IssueListWebservice             *issueListWS;
    NSMutableArray                  *arrAnnotations;
    
    BOOL                            recentlyOpend;
    dispatch_once_t                 onceFlag;
    dispatch_once_t                 onceFancyTabbar;
}

@property (nonatomic,weak)      IBOutlet    UIView                  *vwHeader;
@property (nonatomic,weak)      IBOutlet    UIView                  *vwAdevertise;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblCategory;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnCategory;
@property (nonatomic,weak)      IBOutlet    MKMapView               *mapView;
@property (nonatomic,strong)                FancyTabBar             *fancyTabBar;
@property (nonatomic,strong)                UIImageView             *backgroundView;

@property (nonatomic,strong)    IBOutlet    UIView                  *filterViewContainer;
@property (nonatomic,strong)                UIView                  *filterView;
@property (nonatomic,weak)      IBOutlet    NSLayoutConstraint      *cnstFilterVWHeight;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnAll;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnRecycling;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnCleanliness;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnDisaster;
@property (nonatomic,weak)      IBOutlet    UIButton                *btnSafety;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblAll;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblRecycling;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblCleanliness;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblDisaster;
@property (nonatomic,weak)      IBOutlet    UILabel                 *lblSafety;
@property (nonatomic,weak)      IBOutlet    UIImageView             *imgAll;
@property (nonatomic,weak)      IBOutlet    UIImageView             *imgRecycling;
@property (nonatomic,weak)      IBOutlet    UIImageView             *imgCleanliness;
@property (nonatomic,weak)      IBOutlet    UIImageView             *imgDisaster;
@property (nonatomic,weak)      IBOutlet    UIImageView             *imgSafety;

@property (nonatomic,weak)                  KIPLAnnotationView      *selectedAnnoteView;

-(IBAction)btnCategory_didSelected:(id)sender;



@end


