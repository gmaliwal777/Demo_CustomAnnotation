//
//  CallOutCell.h
//  eCitzens
//
//  Created by Ghanshyam on 4/7/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsynImageDownLoad.h"

@interface CallOutCell : UITableViewCell{
    
}

@property (nonatomic,weak)      IBOutlet    UIButton                    *btnAction;
@property (nonatomic,weak)      IBOutlet    UIActivityIndicatorView     *indicator;
@property (nonatomic,strong)    IBOutlet    UIView                      *view;
@property (nonatomic,weak)      IBOutlet    UIImageView                 *imgTag;
@property (nonatomic,weak)      IBOutlet    UIImageView                 *imgDisclosure;
@property (nonatomic,weak)      IBOutlet    UILabel                     *lblTagName;
@property (nonatomic,assign)                CategoryType                category;
@property (nonatomic,weak)                  AsynImageDownLoad           *asyncDownload;



-(void)SetUpView;


@end
