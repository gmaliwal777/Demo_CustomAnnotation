//
//  MapVC.m
//  eCitizens
//
//  Created by Ghanshyam on 3/10/15.
//  Copyright (c) 2015 Suchita. All rights reserved.
//


#import "MapVC.h"
#import "UIView+Screenshot.h"
#import "UIImage+ImageEffects.h"
#import "KIPLAnnotation.h"
#import "KIPLAnnotationView.h"
#import "AppIssue.h"
#import "ISSUE.h"
#import "CATEGORY.h"
#import "CallOutView.h"
#import "ContectDetail.h"
#import "SettingViewController.h"
#import "ARVC.h"
#import "ThanksView.h"
#import "MBProgressHUD.h"
#import "UIImage+ImageEffects.h"
#import "ThanksView.h"

@interface MapVC ()

@end

@implementation MapVC

#pragma mark--
#pragma mark-- ViewController LifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    recentlyPostedIssueID = -1;
    
    UITapGestureRecognizer* tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedOnView:)];
    self.view.userInteractionEnabled=YES;
    [self.view addGestureRecognizer:tapGesture];
    
    
    
    //Getting Default Coordinate
    defaultCenterCordinate = [_mapView convertPoint:_mapView.center toCoordinateFromView:_mapView];
    
    //Making Filter View Height to 0 Default
    [_cnstFilterVWHeight setConstant:121];
    category = CAT_ALL;
    
    //Annotation Container Initialization
    arrAnnotations = [[NSMutableArray alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    AppDelegate *appdelgate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    int stackCount = (int)appdelgate.navigationController.viewControllers.count;
    if (stackCount>1) {
        UIViewController *topLastVC = [[appdelgate.navigationController viewControllers] objectAtIndex:stackCount-2];
        [MBProgressHUD hideAllHUDsForView:topLastVC.view animated:NO];
    }
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    
    // Status bas hidden or white
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        [self preferredStatusBarStyle];
        [self setNeedsStatusBarAppearanceUpdate];
    }else{
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if(callWebservice){
        NSLog(@"call webservice again");
        [self callIssueListWebservice];
        callWebservice = NO;
    }
    
    NSLog(@"filter container frame is %@",NSStringFromCGRect(_filterViewContainer.frame));
    if (_filterView == nil) {
        _filterView = (UIView *)[[[NSBundle mainBundle] loadNibNamed:@"FilterView" owner:self options:nil] lastObject];
        _filterView.frame = CGRectMake(0, -(300-121), _filterViewContainer.frame.size.width,300);
        [_filterViewContainer addSubview:_filterView];
    }
    
    //Setup Notification for DataLoading
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(callIssueListWebservice) name:MapDataLoadingNotification object:nil];
    
    // Notification Observer
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(centerCallOut:) name:centerCallOutNotification object:nil];
    dispatch_once(&dispatchMapInitialization, ^{
        [self setUpView];
        [self InitializeMap];
        [self fetchIssuesList];
    });

}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    dispatch_once(&onceFancyTabbar, ^{
        
    });
}

#pragma mark--
#pragma mark-- IssueListDelegate
-(void)issueListFailure{
    if (issueListWS) {
        issueListWS = nil;
    }
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    int stackCount = (int)appdelegate.navigationController.viewControllers.count;
    if (stackCount>1) {
        UIViewController *topLastVC = [[appdelegate.navigationController viewControllers] objectAtIndex:stackCount-2];
        [MBProgressHUD hideAllHUDsForView:topLastVC.view animated:NO];
    }
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

-(void)issueListSucceded{
    if (issueListWS) {
        issueListWS = nil;
    }
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    int stackCount = (int)appdelegate.navigationController.viewControllers.count;
    if (stackCount>1) {
        UIViewController *topLastVC = [[appdelegate.navigationController viewControllers] objectAtIndex:stackCount-2];
        [MBProgressHUD hideAllHUDsForView:topLastVC.view animated:NO];
    }
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
    //Loading refresh issue list
    [self fetchIssuesList];
}

#pragma mark--
#pragma mark-- MapView Setup

-(void)InitializeMap{
    
    MKCoordinateSpan    span;
    span.latitudeDelta  = 0.5;
    span.longitudeDelta = 0.5;
    
    MKCoordinateRegion      region;
    region.span = span;
    CLLocationCoordinate2D centerCoordinate = CLLocationCoordinate2DMake(-20.237577, 57.570443);
    region.center = centerCoordinate;
    _mapView.showsBuildings = YES;
    [_mapView setRegion:region];
}

-(void)addAnnotation:(ISSUE *)issue{
    //Initially adding annotation on map to show Location 26.917359, 75.785408
    //MKPointAnnotation
    float latitude = [issue.latitude floatValue];
    float longitude = [issue.longitude floatValue];
    latitude = [issue.latitude floatValue];
    NSString *strLat = [NSString stringWithFormat:@"%.6f",latitude];
    
    longitude = [issue.longitude floatValue];
    NSString *strLng = [NSString stringWithFormat:@"%.6f",longitude];
    
    KIPLAnnotation *annotation = [[KIPLAnnotation alloc] initWithLocation:CLLocationCoordinate2DMake(latitude, longitude) WithIssue:issue];
    annotation.title = issue.category.code;
    annotation.strLat = strLat;
    annotation.strLng = strLng;
    [_mapView addAnnotation:annotation];
    
    //Keeping Annotation reference
    [arrAnnotations addObject:annotation];
}

-(void)showThanksScreen{
    CGRect frame = CGRectMake(0, self.view.bounds.size.height, self.view.bounds.size.width, self.view.bounds.size.height);
    ThanksView *thanks = [[ThanksView alloc] initWithFrame:frame WithData:nil];
    [self.view addSubview:thanks];
    [UIView animateWithDuration:0.5 animations:^{
        CGRect frame = thanks.frame;
        frame.origin.y = 0;
        thanks.frame = frame;
    }];
}


-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    //PinAnnotation UI Customization
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    if ([annotation isKindOfClass:[KIPLAnnotation class]])
    {
        // Try to dequeue an existing pin view first.
        KIPLAnnotationView *pinView = (KIPLAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
        if (!pinView)
        {
            // If an existing pin view was not available, create one.
            pinView = [[KIPLAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotationView"];
            pinView.enabled = YES;
            pinView.selected = NO;
            pinView.centerOffset = CGPointMake(0, 0);
        }
        pinView.annotation = annotation;

        if ([[(KIPLAnnotation*)pinView.annotation arrIssues] count] == 1)
        {
            ISSUE *issue = [[(KIPLAnnotation*)pinView.annotation arrIssues] objectAtIndex:0];
            
            if ([issue.issue_id longValue] == recentlyPostedIssueID)
            {
                pinView.isRecentlyAdded = YES;
                recentlyPostedIssueID = -1;
            }
        }
        
        pinView.refresh = YES;
        [pinView addObserver:self forKeyPath:@"selection" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
        KIPLAnnotation *kiplAnnote = (KIPLAnnotation *)annotation;
        
        if (category == CAT_ALL) {
            [pinView setHidden:NO];
        }else{
            NSString *categoryVal = @"";
            if (category == CAT_CLEANLINESS) {
                categoryVal = CLEANLINESS;
            }else if (category == CAT_DISASTER){
                categoryVal = DISASTER;
            }else if (category == CAT_RECYCLING){
                categoryVal = RECYCLING;
            }else if (category == CAT_SAFETY){
                categoryVal = SAFETY;
            }
            
            NSArray *arrIssues = kiplAnnote.arrIssues;
            BOOL hide = YES;
            for (ISSUE *issue in arrIssues) {
                if ([[issue.category.code uppercaseString] isEqualToString:categoryVal]) {
                    hide = NO;
                    break;
                }
            }
            
            [pinView setHidden:hide];
        }
        
        
        return pinView;
    }
    return nil;
}
- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated{
    NSLog(@"region did changd");
    if (_selectedAnnoteView) {
        NSLog(@"region did change bring front");
        [_selectedAnnoteView bringCallOutInFront];
    }
}

#pragma mark--
#pragma mark-- KVO Implementation
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString:@"selection"]) {
        NSLog(@"selection is selected %@",change);
        if ([[change objectForKey:@"new"] boolValue] == YES) {
            if(self.filterView.frame.origin.y == 114){
                //Filter View is opend need to be closed
                [self btnCategory_didSelected:nil];
            }
            [self hideOtherCallOutView];
            //NSLog(@"map rect is %@",NSStringFromCGRect(_mapView.visibleMapRect));
        }
    }
}

#pragma mark--
#pragma mark-- IBAction Methods
-(IBAction)categoryFilterAction:(id)sender{
    NSLog(@"category selection");
    if (_fancyTabBar.isExpanded && recentlyOpend==NO) {
        [_fancyTabBar collapseAnimation];
    }
    
    recentlyOpend = NO;
    
    UIButton *btnSender = (UIButton *)sender;
    [_imgAll setImage:[UIImage imageNamed:@"AllFilterNormalIcon"]];
    [_imgCleanliness setImage:[UIImage imageNamed:@"CleanlinessNormalIcon"]];
    [_imgDisaster setImage:[UIImage imageNamed:@"DisasterNormalIcon"]];
    [_imgRecycling setImage:[UIImage imageNamed:@"RecycleNormalIcon"]];
    [_imgSafety setImage:[UIImage imageNamed:@"SafetyNormalIcon"]];
    
    
    [_lblAll setTextColor:[UIColor colorWithRed:77/255.0f green:77/255.0f blue:77/255.0f alpha:1]];
    [_lblCleanliness setTextColor:[UIColor colorWithRed:77/255.0f green:77/255.0f blue:77/255.0f alpha:1]];
    [_lblDisaster setTextColor:[UIColor colorWithRed:77/255.0f green:77/255.0f blue:77/255.0f alpha:1]];
    [_lblRecycling setTextColor:[UIColor colorWithRed:77/255.0f green:77/255.0f blue:77/255.0f alpha:1]];
    [_lblSafety setTextColor:[UIColor colorWithRed:77/255.0f green:77/255.0f blue:77/255.0f alpha:1]];
    
    [_btnAll setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.9]];
    [_btnCleanliness setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.9]];
    [_btnRecycling setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.9]];
    [_btnDisaster setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.9]];
    [_btnSafety setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.9]];
    
    if (btnSender == _btnAll) {
        //All Category
        category = CAT_ALL;
        [_imgAll setImage:[UIImage imageNamed:@"AllFilterHighIcon"]];
        [_lblAll setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [_btnAll setBackgroundColor:[UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1.0]];
        [_lblCategory setText:@"All"];
        [self filterAnnotation:ALL];
        
    }else if (btnSender == _btnCleanliness){
        //Cleanliness Category
        category = CAT_CLEANLINESS;
        [_imgCleanliness setImage:[UIImage imageNamed:@"CleanlinessHighIcon"]];
        [_lblCleanliness setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [_btnCleanliness setBackgroundColor:[UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1.0]];
        [_lblCategory setText:@"Cleanliness"];
        [self filterAnnotation:CLEANLINESS];
        
    }else if (btnSender == _btnRecycling){
        //Recycling
        category = CAT_RECYCLING;
        [_imgRecycling setImage:[UIImage imageNamed:@"RecycleHighIcon"]];
        [_lblRecycling setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [_btnRecycling setBackgroundColor:[UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1.0]];
        [_lblCategory setText:@"Recycling"];
        [self filterAnnotation:RECYCLING];
        
    }else if (btnSender == _btnDisaster){
        //Disaster
        category = CAT_DISASTER;
        [_imgDisaster setImage:[UIImage imageNamed:@"DisasterHighIcon"]];
        [_lblDisaster setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [_btnDisaster setBackgroundColor:[UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1.0]];
        [_lblCategory setText:@"Disaster"];
        [self filterAnnotation:DISASTER];
        
    }else if (btnSender == _btnSafety){
        //Safety
        category = CAT_SAFETY;
        [_imgSafety setImage:[UIImage imageNamed:@"SafetyHighIcon"]];
        [_lblSafety setTextColor:[UIColor colorWithRed:255/255.0f green:87/255.0f blue:34/255.0f alpha:1]];
        [_btnSafety setBackgroundColor:[UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1.0]];
        [_lblCategory setText:@"Safety"];
        [self filterAnnotation:SAFETY];
        
    }
}


-(IBAction)btnCategory_didSelected:(id)sender
{
    
    if ([[_lblCategory.text uppercaseString] isEqualToString:CLEANLINESS]) {
        [self categoryFilterAction:_btnCleanliness];
    }else if ([[_lblCategory.text uppercaseString] isEqualToString:ALL]){
        [self categoryFilterAction:_btnAll];
    }else if ([[_lblCategory.text uppercaseString] isEqualToString:DISASTER]){
        [self categoryFilterAction:_btnDisaster];
    }else if ([[_lblCategory.text uppercaseString] isEqualToString:RECYCLING]){
        [self categoryFilterAction:_btnRecycling];
    }else if ([[_lblCategory.text uppercaseString] isEqualToString:SAFETY]){
        [self categoryFilterAction:_btnSafety];
    }
    
    [self showHideFilterView];
    if (_selectedAnnoteView) {
        [_selectedAnnoteView hideCallOutView];
        _selectedAnnoteView = nil;
    }
}

-(IBAction)showHideFilterView{
    [UIView animateWithDuration:0.5 animations:^{
        CGRect frame = self.filterView.frame;
        if (frame.origin.y == 121) {
            //Already open , need to close filterView
            frame.origin.y = -(300-121);
            self.filterView.frame = frame;
            [_cnstFilterVWHeight setConstant:121];
            [_btnCategory setImage:[UIImage imageNamed:@"DropDownOpenArrow"] forState:UIControlStateNormal];
        }else{
            //Closed , need to open filterView
            frame.origin.y = 121;
            self.filterView.frame = frame;
            [_btnCategory setImage:[UIImage imageNamed:@"DropDownCloseArrow"] forState:UIControlStateNormal];
        }
    } completion:^(BOOL finished) {
        CGRect frame = self.filterView.frame;
        if (frame.origin.y == 121) {
            [_cnstFilterVWHeight setConstant:(300+121)];
        }
    }];
}


#pragma mark--
#pragma mark-- Custom Methods

-(void)callIssueListWebservice{
    issueListWS = [[IssueListWebservice alloc] init];
    issueListWS.delegate = self;
    [issueListWS callIssuesListWebservice];
}


-(void)filterAnnotation:(NSString *)categoryVal{
    NSArray *arrAnnotations = [_mapView annotations];
    for (KIPLAnnotation *annotation in arrAnnotations) {
        KIPLAnnotationView *annoteView = (KIPLAnnotationView *)[_mapView viewForAnnotation:annotation];
        [annoteView setHidden:NO];
    }
    if (![categoryVal isEqualToString:ALL]) {
        for (KIPLAnnotation *annotation in arrAnnotations) {
            NSArray *arrIssues = annotation.arrIssues;
            BOOL hide = YES;
            for (ISSUE *issue in arrIssues) {
                if ([[issue.category.code uppercaseString] isEqualToString:categoryVal]) {
                    hide = NO;
                    break;
                }
            }
            KIPLAnnotationView *annoteView = (KIPLAnnotationView *)[_mapView viewForAnnotation:annotation];
            [annoteView setHidden:hide];
//            if (![[annotation.title uppercaseString] isEqualToString:categoryVal]) {
//                KIPLAnnotationView *annoteView = (KIPLAnnotationView *)[_mapView viewForAnnotation:annotation];
//                [annoteView setHidden:YES];
//            }
        }
    }
}



-(void)centerCallOut:(NSNotification *)notification{
    NSLog(@"centerCallOut");
    KIPLAnnotationView *annoteView = (KIPLAnnotationView *)notification.object;
    [_mapView bringSubviewToFront:annoteView];
    [annoteView bringCallOutInFront];
    _selectedAnnoteView = annoteView;
    
    MKCoordinateRegion region = [_mapView convertRect:annoteView.frame toRegionFromView:_mapView];
    [_mapView setRegion:region animated:YES];
}

-(void)hideOtherCallOutView{
    NSArray *arrAnnotations = _mapView.annotations;
    for (KIPLAnnotation *annotation in arrAnnotations) {
        KIPLAnnotationView *annotationView = (KIPLAnnotationView *)[_mapView viewForAnnotation:annotation];
        if ([annotationView getSelection]) {
            [annotationView hideCallOutView];
        }
    }
}

-(KIPLAnnotation *)doesMapHasAnnotationAtLocation:(NSString *)strLat strLng:(NSString *)strLng InAnnotationGroup:(NSArray *)annotationGroup{
    
    NSArray *arrAnnotations = _mapView.annotations;
    for (int counter = 0;counter<arrAnnotations.count;counter++) {
        KIPLAnnotation *annot = [arrAnnotations objectAtIndex:counter];
        if ([annot.strLat isEqualToString:strLat]
            &&[annot.strLng isEqualToString:strLng]) {
            return annot;
        }
    }
    
    return nil;
}


-(void)fetchIssuesList{

    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    UIViewController *topVC = (UIViewController *)[[appdelegate.navigationController viewControllers] lastObject];
    [MBProgressHUD showHUDAddedTo:topVC.view animated:YES];
    
    
    NSManagedObjectContext *context  = [appdelegate managedObjectContext];
    
    NSFetchRequest  *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"ISSUE"];

    NSError *error;
    NSArray *arrIssues    = [context executeFetchRequest:fetchRequest error:&error];
    
    float latitude=0.0;
    float longitude=0.0;
   // arrPINS = [[NSMutableArray alloc] init];
    
    if (!error && [arrIssues count]>0) {
        
        //Removing Previous Annotation and Loading refresh Annotation
//        if ([arrAnnotations count]>0) {
//            [_mapView removeAnnotations:arrAnnotations];
//            [arrAnnotations removeAllObjects];
//        }
        
        
        for (int counter = 0; counter<arrIssues.count; counter++) {
            ISSUE *issue = [arrIssues objectAtIndex:counter];
            latitude = [issue.latitude floatValue];
            NSString *strLat = [NSString stringWithFormat:@"%.6f",latitude];
            
            longitude = [issue.longitude floatValue];
            NSString *strLng = [NSString stringWithFormat:@"%.6f",longitude];
            
            KIPLAnnotation *annotation = [self doesMapHasAnnotationAtLocation:strLat strLng:strLng InAnnotationGroup:arrPINS];
            NSLog(@"issue lat = %f , lng = %f",[issue.latitude floatValue],[issue.longitude floatValue]);
            if (annotation == nil) {
                [self addAnnotation:issue];
            }else{
                if (onceFlag) {
                    BOOL alreadyAdded = [annotation alreadyAdded:issue];
                    if (!alreadyAdded) {
                        [annotation addMoreIssue:issue];
                    }
                }else{
                    //Initial Loading
                    [annotation addMoreIssue:issue];
                }
                
                KIPLAnnotationView *annotationView = (KIPLAnnotationView *)[_mapView viewForAnnotation:annotation];
                if ([issue.issue_id longValue] == recentlyPostedIssueID)
                {
                    annotationView.isRecentlyAdded = YES;
                    recentlyPostedIssueID = -1;
                }
                annotationView.refresh = YES;
            }
        }
    }
    
    [MBProgressHUD hideHUDForView:topVC.view animated:YES];
    
    dispatch_once(&onceFlag, ^{
        
    });
}

-(void)tappedOnFacny{
    [_fancyTabBar collapseAnimation];
}


-(void)tappedOnView:(UITapGestureRecognizer*)sender{
    if(_selectedAnnoteView) {
        
        [_selectedAnnoteView hideCallOutView];
        _selectedAnnoteView = nil;
    }
}

-(void)setUpView{
//    NSArray *arrTitle =@[@{@"title":@"Settings",@"color":[UIColor blackColor]},
//                         @{@"title":@"Report Issue",@"color":[UIColor blackColor]}
//                         ,@{@"title":@"Near Me",@"color":[UIColor blackColor]}
//                         ,@{@"title":@"News",@"color":[UIColor blackColor]}
//                         ,@{@"title":@"My Issues",@"color":[UIColor blackColor]}];
    
    NSArray *arrTitle =@[@{},@{},@{},@{},@{}];
    CGRect fancyFrame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height-5);
    _fancyTabBar = [[FancyTabBar alloc]initWithFrame:fancyFrame];
    [_fancyTabBar setUpChoices:self choices:@[@"MapSettingIcon",@"MapCameraIcon",@"MapArtIcon",@"MapNewsIcon",@"MapMyIssuesIcon"] withMainButtonImage:[UIImage imageNamed:@"TabBarOpenIcon"] WithChoicesTitle:arrTitle];
    _fancyTabBar.delegate = self;
    [self.view addSubview:_fancyTabBar];
    
    UITapGestureRecognizer* tapGestureFacny=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedOnFacny)];
    [_fancyTabBar addGestureRecognizer:tapGestureFacny];
}

- (BOOL) isGyroscopeAvailable
{
#ifdef __IPHONE_4_0
    CMMotionManager *motionManager = [[CMMotionManager alloc] init];
    BOOL gyroAvailable = motionManager.gyroAvailable;
    [motionManager release];
    return gyroAvailable;
#else
    return NO;
#endif
    
}

-(BOOL)isCameraEnabled{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    
    if(status == AVAuthorizationStatusAuthorized) {
        // authorized
        // Initialize camera
        return YES;
    } else if(status == AVAuthorizationStatusDenied){
        // denied
    } else if(status == AVAuthorizationStatusRestricted){
        // restricted
    } else if(status == AVAuthorizationStatusNotDetermined){
        // not determined
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if(granted){
                NSLog(@"Granted access");
            } else {
                NSLog(@"Not granted access");
            }
        }];
    }
    return NO;
}

- (BOOL) compassAvailable{
    BOOL compassAvailable = NO;
#ifdef __IPHONE_3_0
    compassAvailable = [CLLocationManager headingAvailable];
#else
    CLLocationManager *cl = [[CLLocationManager alloc] init];
    compassAvailable = cl.headingAvailable;
    [cl release];
#endif
    return compassAvailable;
}

#pragma mark--
#pragma mark - FancyTabBarDelegate

- (void)optionsButton:(UIButton*)optionButton didSelectItem:(int)index{
    NSLog(@"index value is %d",index);
    //[_fancyTabBar collapseAnimation];
    NSLog(@"compass is = %@",([self compassAvailable]?@"YES":@"NO"));
    if (index==2) {
        //Checking whether Local DB existing for Issue Posting
        AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *context = [appdelegate managedObjectContext];
        
        NSFetchRequest *categoryRequest = [[NSFetchRequest alloc] initWithEntityName:@"CATEGORY"];
        NSError *categoryError;
        NSArray *arrCategory = [context executeFetchRequest:categoryRequest error:&categoryError];
        if ([arrCategory count]>0) {
            [self performSegueWithIdentifier:@"SHOWCAMERA_SEGUE_IDENTIFIER" sender:nil];
        }else{
            NSMutableArray *arrActions = [[NSMutableArray alloc] init];
            
            //Ok Button
            NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            },@"action", nil];
            [arrActions addObject:dictTab];
            
            alert = [[AlertView alloc] init];
            [alert showAlertView:@"No Connection, Please check your Internet connection" arrActions:arrActions];
        }
    }else if(index==5){
        if ([CommonFunction networkConnectionAvailability]) {
            //Calling Posting Issue webservice
            if ([FBSDKAccessToken currentAccessToken] != nil) {
                [self performSegueWithIdentifier:@"MYISSUES_SEGUE_IDENTIFIER" sender:nil];
            }else{
                [self.view endEditing:YES];
                AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
                [appdelegate showLoginPopuponRef:self];
            }
        }else{
            if ([FBSDKAccessToken currentAccessToken] != nil) {
                [self performSegueWithIdentifier:@"MYISSUES_SEGUE_IDENTIFIER" sender:nil];
            }else{
                alert = [[AlertView alloc] init];
                NSMutableArray *arrActions = [[NSMutableArray alloc] init];
                
                NSDictionary *dictOk = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
                },@"action", nil];
                
                [arrActions addObject:dictOk];
                [alert showAlertView:@"No Connection, Please check your Internet connection" arrActions:arrActions];
            }
            
        }
    }else if (index == 4){
//        [self showThanksScreen];
        [self performSegueWithIdentifier:@"NEWS_SEGUE_IDENTIFIER" sender:nil];
    }else if (index == 3){
        //[self performSegueWithIdentifier:@"AR_SEGUE_IDENTIFIER" sender:nil];
        
        CLAuthorizationStatus authStatus = [CLLocationManager authorizationStatus];
        if (authStatus == kCLAuthorizationStatusDenied||
            authStatus == kCLAuthorizationStatusNotDetermined) {
            alert = [[AlertView alloc] init];
            NSMutableArray *arrActions = [[NSMutableArray alloc] init];
            
            NSDictionary *dictOk = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
            },@"action", nil];
            
            [arrActions addObject:dictOk];
            [alert showAlertView:@"location service needs to be enabled, please check your device settings" arrActions:arrActions];
        }else if(![self isGyroscopeAvailable] || ![self compassAvailable]){
            alert = [[AlertView alloc] init];
            NSMutableArray *arrActions = [[NSMutableArray alloc] init];
            
            NSDictionary *dictOk = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
                
            },@"action", nil];
            
            [arrActions addObject:dictOk];
            [alert showAlertView:@"device is not AR(gyroscope and compass) supported" arrActions:arrActions];
        }else if(![self isCameraEnabled]){
            alert = [[AlertView alloc] init];
            NSMutableArray *arrActions = [[NSMutableArray alloc] init];
            
            NSDictionary *dictOk = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
            },@"action", nil];
            
            [arrActions addObject:dictOk];
            [alert showAlertView:@"camera is not enabled, please check your device setting" arrActions:arrActions];
        }else{
            [self performSegueWithIdentifier:@"AR_SEGUE_IDENTIFIER" sender:nil];
        }
        
        // [self performSegueWithIdentifier:@"AR_SEGUE_IDENTIFIER" sender:nil];
        
    }else if (index == 1){
        
        [self performSegueWithIdentifier:@"SETTING_SEGUE_IDENTIFIER" sender:nil];
        
   }
}

- (void) didCollapse{
    _mapView.userInteractionEnabled = YES;
    [UIView animateWithDuration:0.3 animations:^{
        _backgroundView.alpha = 0;
    } completion:^(BOOL finished) {
        if(finished) {
            [_backgroundView removeFromSuperview];
            _backgroundView = nil;
        }
    }];
}

- (void) didExpand{
    
    _mapView.userInteractionEnabled = NO;
    recentlyOpend = YES;
    if(self.filterView.frame.origin.y == 114){
        //Filter View is opend need to be closed
        [self btnCategory_didSelected:nil];
    }
    
    [self tappedOnView:nil];
    if(!_backgroundView){
//        _backgroundView = [[UIImageView alloc]initWithFrame:self.view.bounds];
        _backgroundView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        _backgroundView.alpha = 0;
//        [_backgroundView setBackgroundColor:[UIColor clearColor]];
        UIImage *backgroundImage = [self.view convertViewToImage];
        UIColor *tintColor = [UIColor colorWithWhite:1.0 alpha:0.5];
        UIImage *image = [backgroundImage applyBlurWithRadius:10 tintColor:tintColor saturationDeltaFactor:1.8 maskImage:nil];
        
        [_backgroundView setImage:image];
        [self.view addSubview:_backgroundView];
    }
    
    [UIView animateWithDuration:0.3 animations:^{
        _backgroundView.alpha = 1;
    } completion:^(BOOL finished) {
        [self.view bringSubviewToFront:_fancyTabBar];
        //[self.view bringSubviewToFront:_vwHeader];
        recentlyOpend = NO;
    }];
    [self.view bringSubviewToFront:_backgroundView];
    [self.view bringSubviewToFront:_fancyTabBar];
    
    
}
#pragma mark--
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([[segue identifier] isEqualToString:@"SHOWCAMERA_SEGUE_IDENTIFIER"])
    {
        
    }else if ([[segue identifier] isEqualToString:@"AR_SEGUE_IDENTIFIER"]){
        //AR View
        ARVC *arVC = [segue destinationViewController];
        arVC.userLocation = [_mapView userLocation];
    }
}

#pragma mark - YCameraViewController Delegate
- (void)didFinishPickingImage:(UIImage *)image{
    NSLog(@"%@",image);
}

- (void)yCameraControllerdidSkipped{
    NSLog(@"skipped");
}

- (void)yCameraControllerDidCancel{
    
    NSLog(@"cancel");
}

#pragma mark--
#pragma mark-- Rotation Methods
-(BOOL)shouldAutorotate{
    NSLog(@"should autorotate");
    return YES;
}

-(NSUInteger)supportedInterfaceOrientations{
    NSLog(@"supported orientation");
    return UIInterfaceOrientationMaskPortrait;
}



@end
