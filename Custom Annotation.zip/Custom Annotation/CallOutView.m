//
//  CallOutView.m
//  eCitzens
//
//  Created by Ghanshyam on 4/6/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "CallOutView.h"
#import "CallOutCell.h"
#import "ISSUE.h"
#import "CATEGORY.h"
#import "AsynImageDownLoad.h"
#import "IssueDetailVC.h"
#import "IssueDescriptionVC.h"

@implementation CallOutView

#pragma mark--
#pragma mark-- UIView LifeCycle
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"CallOutView" owner:self options:nil];
        [self setBackgroundColor:[UIColor clearColor]];
        [self.view setBackgroundColor:[UIColor clearColor]];
        [self addSubview:self.view];
        
        //Items initialization
        _arrItems = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    self.view.frame = self.bounds;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    selectedRow = -1;
    [self formateIssues];
}

-(void)dealloc{
    NSLog(@"call out dealloc called");
    self.view.frame = CGRectZero;
    [self.view removeFromSuperview];
    _arrItems = nil;
}


#pragma mark--
#pragma mark-- Custom Methods
-(void)didSelectAction:(UIButton*)btnSender{
    CGPoint buttonPosition = [btnSender convertPoint:CGPointZero toView:_tableView];
    NSIndexPath *indexPath = [_tableView indexPathForRowAtPoint:buttonPosition];
    UITableViewCell *cell = [_tableView cellForRowAtIndexPath:indexPath];
//    cell.backgroundColor = [UIColor colorWithRed:235/255.0f green:235/255.0f blue:235/255.0f alpha:1];
    
    if (indexPath) {
        NSMutableDictionary *container = [_arrItems objectAtIndex:indexPath.section];
        
        if (indexPath.row == 0){
            
            BOOL isOpen = [[container objectForKey:@"isOpen"] boolValue];
            
            [container setObject:[NSNumber numberWithBool:!isOpen] forKey:@"isOpen"];
            
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
            
        }else{
            //Moving directly to Detail Screen
            selectedRow = (int)indexPath.row;
            [_tableView reloadData];
            
            NSMutableArray *issues = [container objectForKey:@"issues"];
            ISSUE *issue = (ISSUE *)[issues objectAtIndex:indexPath.row-1];
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            IssueDetailVC *issueDetailVC = (IssueDetailVC *)[storyboard instantiateViewControllerWithIdentifier:ISSUE_DETAIL_STORYBOARD_ID];
            issueDetailVC.issue = issue;
            issueDetailVC.modellyPresented = YES;
            AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            
            [appdelegate.navigationController presentViewController:issueDetailVC animated:YES completion:NULL];
        }
    }
    
}

-(void)formateIssues{
    
    NSMutableDictionary  *dictIssues = [[NSMutableDictionary alloc] init];
    
    for (ISSUE *localIssue in _arrIssues) {
        NSString *category = localIssue.category.name;
        if ([dictIssues objectForKey:category]) {
            NSMutableArray *arrMutableIssues = [dictIssues objectForKey:category];
            [arrMutableIssues addObject:localIssue];
        }else{
            NSMutableArray *arrMutalbeIssues = [[NSMutableArray alloc] init];
            [arrMutalbeIssues addObject:localIssue];
            [dictIssues setObject:arrMutalbeIssues forKey:category];
        }
    }
    
    NSArray *arrKeys = [dictIssues allKeys];
    for (int counter = 0;counter<arrKeys.count;counter++) {
        NSArray *arrFormattedIssues = [dictIssues objectForKey:[arrKeys objectAtIndex:counter]];
        NSMutableDictionary *dictItem = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[arrKeys objectAtIndex:counter],@"category", nil];
        
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"title" ascending:YES selector:@selector(caseInsensitiveCompare:)];
        NSArray *sortedArray = [NSArray arrayWithObject:sortDescriptor];
        arrFormattedIssues = [arrFormattedIssues sortedArrayUsingDescriptors:sortedArray];
        
        [dictItem setObject:arrFormattedIssues forKey:@"issues"];
        
        [dictItem setObject:[NSNumber numberWithBool:YES] forKey:@"isOpen"];
        
        [_arrItems addObject:dictItem];
    }
    [_tableView reloadData];
}

#pragma mark--
#pragma mark-- TableView Delegate & DataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [_arrItems count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0f;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSDictionary *container = [_arrItems objectAtIndex:section];
    
    BOOL isOpen = [[container objectForKey:@"isOpen"] boolValue];
    
    return isOpen?([[container objectForKey:@"issues"] count]+1):1;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CallOutCell *cell = [tableView dequeueReusableCellWithIdentifier:CALLOUTCELL_DEFAULT_CELL_IDENTIFIER];
    if (cell==nil) {
        cell = [[CallOutCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CALLOUTCELL_DEFAULT_CELL_IDENTIFIER];
        [cell.btnAction addTarget:self action:@selector(didSelectAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    NSLog(@"selected row is %d",selectedRow);
    
    
    NSDictionary *container = [_arrItems objectAtIndex:indexPath.section];
    
    if (indexPath.row == 0) {
        
        BOOL isOpen = [[container objectForKey:@"isOpen"] boolValue];
        
        //Category section
        if ([[[container objectForKey:@"category"] uppercaseString] isEqualToString:CLEANLINESS]) {
            cell.category = CAT_CLEANLINESS;
            cell.lblTagName.text = [container objectForKey:@"category"];
            cell.imgDisclosure.image = isOpen?[UIImage imageNamed:@"clean_up_arrow"]:[UIImage imageNamed:@"clean_down_arrow"];
        }else if ([[[container objectForKey:@"category"] uppercaseString] isEqualToString:DISASTER]){
            cell.category = CAT_DISASTER;
             cell.lblTagName.text = [container objectForKey:@"category"];
            cell.imgDisclosure.image = isOpen?[UIImage imageNamed:@"disaster_up_arrow"]:[UIImage imageNamed:@"disaster_down_arrow"];
        }else if ([[[container objectForKey:@"category"] uppercaseString] isEqualToString:RECYCLING]){
            cell.category = CAT_RECYCLING;
             cell.lblTagName.text = [container objectForKey:@"category"];
            cell.imgDisclosure.image = isOpen?[UIImage imageNamed:@"recycle_up_arrow"]:[UIImage imageNamed:@"recycle_down_arrow"];
        }else if ([[[container objectForKey:@"category"] uppercaseString] isEqualToString:SAFETY]){
            cell.category = CAT_SAFETY;
             cell.lblTagName.text = [container objectForKey:@"category"];
            cell.imgDisclosure.image = isOpen?[UIImage imageNamed:@"safety_up_arrow"]:[UIImage imageNamed:@"safety_down_arrow"];
        }
    }else{
        //Issue Section
        cell.category = CAT_NOT;
        
        // use coder and decoder
        
        NSMutableArray *issues = [container objectForKey:@"issues"];
        
        ISSUE *issue = (ISSUE *)[issues objectAtIndex:indexPath.row-1];
//        cell.lblTagName.text = issue.title;
        cell.lblTagName.text = [IssueDescriptionVC convertUnicodeToEmoji:issue.title];
        cell.imgDisclosure.image = [UIImage imageNamed:@"more"];
        if ([CommonFunction networkConnectionAvailability]) {
            NSString *thumbnailURL = issue.thumbnail;
            NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
            NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
            NSString *cachePath = [arrPaths objectAtIndex:0];
            NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if(thumbnailURL && [fileManager fileExistsAtPath:localThumbnailPath]){
                cell.imgTag.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
                [cell.indicator stopAnimating];
            }else if(thumbnailURL){
                AsynImageDownLoad *asynImageDownLoad = [[AsynImageDownLoad alloc] init];
                cell.asyncDownload = asynImageDownLoad;
                [asynImageDownLoad downLoadingAsynImage:cell.imgTag imagePath:thumbnailURL backgroundQueue:NULL];
            }else{
                [cell.imgTag setImage:[UIImage imageNamed:@"Placeholder_image"]];
                [cell.indicator stopAnimating];
            }
        }else{
            //Default Issue Image
            NSString *thumbnailURL = issue.thumbnail;
            NSString *thumbnailName = [[thumbnailURL componentsSeparatedByString:@"/"] lastObject];
            NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
            NSString *cachePath = [arrPaths objectAtIndex:0];
            NSString *localThumbnailPath = [cachePath stringByAppendingPathComponent:thumbnailName];
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if ([fileManager fileExistsAtPath:localThumbnailPath]) {
                cell.imgTag.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:localThumbnailPath]];
                [cell.indicator stopAnimating];
            }else{
                [cell.imgTag setImage:[UIImage imageNamed:@"Placeholder_image"]];
                [cell.indicator stopAnimating];
            }
        }
        
    }
    
    
    NSLog(@"selected row is %d",selectedRow);
    if (selectedRow == indexPath.row) {
        [cell setBackgroundColor:[UIColor colorWithRed:232/255.0f green:232/255.0f blue:232/255.0f alpha:1]];
        NSLog(@"selected here");
    }else{
        [cell SetUpView];
    }
    
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"callout didselect");
    
    if (indexPath) {
        NSMutableDictionary *container = [_arrItems objectAtIndex:indexPath.section];
        
        if (indexPath.row == 0){
            
            BOOL isOpen = [[container objectForKey:@"isOpen"] boolValue];
            
            [container setObject:[NSNumber numberWithBool:!isOpen] forKey:@"isOpen"];
            
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
            
        }else{
            //Moving directly to Detail Screen
            NSMutableArray *issues = [container objectForKey:@"issues"];
            ISSUE *issue = (ISSUE *)[issues objectAtIndex:indexPath.row-1];
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            IssueDetailVC *issueDetailVC = (IssueDetailVC *)[storyboard instantiateViewControllerWithIdentifier:ISSUE_DETAIL_STORYBOARD_ID];
            issueDetailVC.issue = issue;
            issueDetailVC.modellyPresented = YES;
            AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            
            [appdelegate.navigationController presentViewController:issueDetailVC animated:YES completion:NULL];
        }
    }
}



@end
