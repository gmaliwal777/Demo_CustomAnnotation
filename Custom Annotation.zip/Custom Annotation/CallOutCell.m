//
//  CallOutCell.m
//  eCitzens
//
//  Created by Ghanshyam on 4/7/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "CallOutCell.h"

@implementation CallOutCell

#pragma mark--
#pragma mark-- UITableViewCell Life Cycel
- (void)awakeFromNib {
    // Initialization code
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //Custom Initialization
        [[NSBundle mainBundle] loadNibNamed:@"CallOutCell" owner:self options:nil];
        [self addSubview:self.view];
        
        _imgTag.layer.cornerRadius = _imgTag.frame.size.height/2;
        _imgTag.layer.masksToBounds = YES;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

-(void)drawRect:(CGRect)rect{
    self.view.frame = self.bounds;
}
-(void)prepareForReuse{
    if (self.asyncDownload) {
        _asyncDownload.imgView = nil;
        [_asyncDownload cancelDownLoading];
    }
    [self.indicator startAnimating];
    
    _imgTag.image = nil;
    _lblTagName.text = @"";
    [[NSNotificationCenter defaultCenter] removeObserver:self ];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self ];
}


#pragma mark--
#pragma mark-- Custom Methods

-(void)SetUpView{
    //Default Setup As Treating Category Cell
    _lblTagName.font = [UIFont fontWithName:@"Helvetica Neue Medium" size:17];
    [self setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1]];
    
    
    if (_category == CAT_NOT) {
        //Issue Detail
        [_lblTagName setTextColor:[UIColor colorWithRed:79/255.0F green:79/255.0f blue:79/255.0f alpha:1]];
        _lblTagName.font = [UIFont fontWithName:@"Helvetica Neue Regular" size:17];
        [self setBackgroundColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1]];
    }else if (_category == CAT_CLEANLINESS){
        //Cleanliness
        //[_lblTagName setText:@"CLEANLINESS"];
        [_lblTagName setTextColor:[UIColor colorWithRed:3/255.0F green:169/255.0f blue:244/255.0f alpha:1]];
        _imgTag.image = [UIImage imageNamed:@"CleanlinessItemIcon"];
        [_indicator stopAnimating];
    }else if (_category == CAT_DISASTER){
        //DISASTER
        //[_lblTagName setText:@"DISASTER"];
        [_lblTagName setTextColor:[UIColor colorWithRed:121/255.0F green:85/255.0f blue:72/255.0f alpha:1]];
        _imgTag.image = [UIImage imageNamed:@"DisasterItemIcon"];
        [_indicator stopAnimating];
    }else if (_category == CAT_RECYCLING){
        //RECYCLING
        //[_lblTagName setText:@"RECYCLING"];
        [_lblTagName setTextColor:[UIColor colorWithRed:85/255.0F green:139/255.0f blue:47/255.0f alpha:1]];
        _imgTag.image = [UIImage imageNamed:@"RecycleItemIcon"];
        [_indicator stopAnimating];
    }else if (_category == CAT_SAFETY){
        //SAFETY
        //[_lblTagName setText:@"SAFETY"];
        [_lblTagName setTextColor:[UIColor colorWithRed:255/255.0F green:64/255.0f blue:129/255.0f alpha:1]];
        _imgTag.image = [UIImage imageNamed:@"SafetyItemIcon"];
        [_indicator stopAnimating];

//    _lblTagName.font = [UIFont fontWithName:@"Helvetica Neue Medium" size:17];
//    [self setBackgroundColor:[UIColor colorWithRed:232/255.0f green:232/255.0f blue:232/255.0f alpha:1]];
//    
//    
//    if (_category == CAT_NOT) {
//        //Issue Detail
//        [_lblTagName setTextColor:[UIColor colorWithRed:79/255.0F green:79/255.0f blue:79/255.0f alpha:1]];
//        _lblTagName.font = [UIFont fontWithName:@"Helvetica Neue Regular" size:17];
//        [self setBackgroundColor:[UIColor colorWithRed:250/255.0f green:250/255.0f blue:250/255.0f alpha:1]];
//    }else if (_category == CAT_CLEANLINESS){
//        //Cleanliness
//        [_lblTagName setText:@"CLEANLINESS"];
//        [_lblTagName setTextColor:[UIColor colorWithRed:3/255.0F green:169/255.0f blue:244/255.0f alpha:1]];
//        _imgTag.image = [UIImage imageNamed:@"CleanlinessItemIcon"];
//        [_indicator stopAnimating];
//    }else if (_category == CAT_DISASTER){
//        //DISASTER
//        [_lblTagName setText:@"DISASTER"];
//        [_lblTagName setTextColor:[UIColor colorWithRed:121/255.0F green:85/255.0f blue:72/255.0f alpha:1]];
//        _imgTag.image = [UIImage imageNamed:@"DisasterItemIcon"];
//        [_indicator stopAnimating];
//    }else if (_category == CAT_RECYCLING){
//        //RECYCLING
//        [_lblTagName setText:@"RECYCLING"];
//        [_lblTagName setTextColor:[UIColor colorWithRed:85/255.0F green:139/255.0f blue:47/255.0f alpha:1]];
//        _imgTag.image = [UIImage imageNamed:@"RecycleItemIcon"];
//        [_indicator stopAnimating];
//    }else if (_category == CAT_SAFETY){
//        //SAFETY
//        [_lblTagName setText:@"SAFETY"];
//        [_lblTagName setTextColor:[UIColor colorWithRed:255/255.0F green:64/255.0f blue:129/255.0f alpha:1]];
//        _imgTag.image = [UIImage imageNamed:@"SafetyItemIcon"];
//        [_indicator stopAnimating];
    }
}

@end
