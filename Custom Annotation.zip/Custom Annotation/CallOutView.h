//
//  CallOutView.h
//  eCitzens
//
//  Created by Ghanshyam on 4/6/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CallOutView : UIView<UITableViewDelegate,UITableViewDataSource>{
    int selectedRow;
}

@property (nonatomic,strong)    IBOutlet    UITableView             *tableView;
@property (nonatomic,strong)    IBOutlet    UIView                  *view;
@property (nonatomic,weak)                  NSMutableArray          *arrIssues;
@property (nonatomic,strong)                NSMutableArray          *arrItems;


@end
